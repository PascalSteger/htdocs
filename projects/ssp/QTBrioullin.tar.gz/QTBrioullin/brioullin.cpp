/****************************************************************
**
** Implementation BrioullinZone class
**
****************************************************************/

#include "brioullin.h"
#include <qpainter.h>


BrioullinZone::BrioullinZone( QWidget *parent, const char *name )
        : QWidget( parent, name )
{
    setPalette( QPalette( QColor( 250, 250, 200) ) );
}

void BrioullinZone::paintEvent( QPaintEvent * )
{
    QPainter p( this );
    p.setBrush( blue );
    p.setPen( Qt::red );
    int sizex=rect().right(); int sizey=rect().bottom();
    p.translate( sizex/2, sizey/2);

    int dx=0; int dy=0;
    int scalex=sizex/9; int scaley=sizey/9;
    int d=4; //diameter of the circles
    int size=4;
    int factorx=0; int factory=0;

    for(int x=-2*size;x<=2*size;++x){
      for(int y=-2*size;y<=2*size;++y){
	dx=x*scalex; dy=y*scaley;
        factorx=2*dx*size;
        factory=2*dy*size;
	p.drawLine(dx/2,dy/2,dx/2-factory,dy/2+factorx);
        p.drawLine(dx/2,dy/2,dx/2+factory,dy/2-factorx);
      }
    }
    for(int x=-2*size;x<=2*size;++x){
      for(int y=-2*size;y<=2*size;++y){
	dx=x*scalex; dy=y*scaley;
	p.drawEllipse(dx-d,dy-d,2*d,2*d);
      }
    }
}


QSizePolicy BrioullinZone::sizePolicy() const
{
    return QSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );
}
