/****************************************************************************
** BrioullinZone meta object code from reading C++ file 'brioullin.h'
**
** Created: Sat Oct 6 09:07:07 2007
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.1   edited Feb 18 14:21 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "brioullin.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *BrioullinZone::className() const
{
    return "BrioullinZone";
}

QMetaObject *BrioullinZone::metaObj = 0;
static QMetaObjectCleanUp cleanUp_BrioullinZone( "BrioullinZone", &BrioullinZone::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString BrioullinZone::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "BrioullinZone", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString BrioullinZone::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "BrioullinZone", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* BrioullinZone::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"BrioullinZone", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_BrioullinZone.setMetaObject( metaObj );
    return metaObj;
}

void* BrioullinZone::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "BrioullinZone" ) )
	return this;
    return QWidget::qt_cast( clname );
}

bool BrioullinZone::qt_invoke( int _id, QUObject* _o )
{
    return QWidget::qt_invoke(_id,_o);
}

bool BrioullinZone::qt_emit( int _id, QUObject* _o )
{
    return QWidget::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool BrioullinZone::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool BrioullinZone::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
