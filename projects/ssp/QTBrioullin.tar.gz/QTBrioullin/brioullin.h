/****************************************************************
**
** Definition of BrioullinZone class
**
****************************************************************/

#ifndef BRIOULLIN_H
#define BRIOULLIN_H

#include <qwidget.h>


class BrioullinZone : public QWidget
{
    Q_OBJECT
public:
    BrioullinZone( QWidget *parent=0, const char *name=0 );

    QSizePolicy sizePolicy() const;

public slots:

signals:

protected:
    void paintEvent( QPaintEvent * );

private:

};


#endif // BRIOULLIN_H
