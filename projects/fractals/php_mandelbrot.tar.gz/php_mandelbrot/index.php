<?php
if(isset($_GET['wx'])){define('WX', $_GET['wx']);}else{define('WX', 1024);}
if(isset($_GET['wy'])){define('WY', $_GET['wy']);}else{define('WY', 768);}
if(isset($_GET['x'])){define('X', $_GET['x']);}else{define('X', WX/2);}
if(isset($_GET['y'])){define('Y', $_GET['y']);}else{define('Y', WY/2);}
if(isset($_GET['recen'])){$recen=$_GET['recen'];}else{$recen=0.0;}
if(isset($_GET['imcen'])){$imcen=$_GET['imcen'];}else{$imcen=0.0;}
if(isset($_GET['r'])){define('R', $_GET['r']/exp(1));}else{define('R', exp(1));}
define('S', 2.0*exp(1)*R/WX);


echo '
<html><body>
<form>
Fenstergrösse: (<input type="text" name="wx" value="'.WX.'">,<input type="text" name="wy" value="'.WY.'">)<br>
Radius r = <input type="text" name="r" value="'.R.'"><br>
z = <input type="text" name="recen" value="';echo $recen=S*(X-WX/2)+$recen;echo '"> + i * <input type="text" name="imcen" value="';echo $imcen=S*(Y-WY/2)+$imcen;echo '"><br>
<input type="submit" value="Ab damit!"><a href="./index.php">Reset</a><br><br>
<input type="image" src="./man.php?recen='.$recen.'&imcen='.$imcen.'&r='.R.'&wx='.WX.'&wy='.WY.'">

</form></body></html>';
?>