#!/bin/bash

./mandelbrot $1 $2 $3 $4 $4
