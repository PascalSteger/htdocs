<?php
exec("./cpp/mandelbrot $r $wx $wy $recen $imcen && eject /dev/cdrom");
?>