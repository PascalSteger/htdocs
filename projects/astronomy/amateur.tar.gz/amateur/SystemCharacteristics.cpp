/**************************************************************************
 *   Copyright (C) 2008 by Pascal Stephan Philipp Steger                   *
 *   psteger@phys.ethz.ch                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, ma  02111-1307, USA.             *
 ***************************************************************************/

/*!
 * \file SystemCharacteristics.cpp
 * \brief Implementation of all system-wide properties that all parts of the program should know.
 */

#include <string.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
//#include "SystemCharacteristics.h"

/* \brief run a given command */
/* Run a command with system()
 * @param command: command that should be executed
 */
void RunCommand( std::string command ){
  system(command.c_str());
}

/* @brief Count the lines of a textfile */
/**
 * count the lines of a given file
 * @param filename: path to the file
 * @return unsigned number of lines
 */
unsigned GetLineNumber(std::string filename){
  std::ifstream infile(filename.c_str());
  if(!infile)
    return 0;
  unsigned i = 0;
  std::string sd;
  while(getline(infile,sd) && sd.size()>0)
    ++i;

  infile.close();
  return i;
}

/* @brief Reverse a string */
/**
 * Reverse the order of characters in a string
 * @param s: array of chars (<=> string)
 * @return void
 */
void reverse(char s[])
{
  int c, i, j;

  for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
    c = s[i];
    s[i] = s[j];
    s[j] = c;
  }
}

/* \brief Conversion int -> char[] */
/**
 * Converts an integer into a char[ ].
 * @param n: integer that should be printed as a character array
 * @param s: char array that should hold the number
 * @return void
 */
void itoa(int n, char s[])
{
  int i, sign;

  if ((sign = n) < 0)  /* record sign */
    n = -n;          /* make n positive */
  i = 0;
  do {       /* generate digits in reverse order */
    s[i++] = n % 10 + '0';   /* get next digit */
  } while ((n /= 10) > 0);     /* delete it */
  if (sign < 0)
    s[i++] = '-';
  s[i] = '\0';
  reverse(s);
}

/* \brief Conversion int -> std::string */
/**
 * Convert an integer into a string.
 * @param intValue: integer to be converted
 * @return std::string of that integer value
 */
std::string IntToString(int intValue) {
  char *myBuff;
  std::string strRetVal;
  myBuff = new char[100];
  memset(myBuff,'\0',100);

  itoa(intValue,myBuff);

  strRetVal = myBuff;
  delete[] myBuff;
  return(strRetVal);
}

/* \brief returns folder position */
/**
 * Returns the paths to all important folders.
 * @param where: which folder? allowed: amd, snap, amateur, output
 * @return std::string full path
 */
std::string Folder(std::string where){
  std::string folder_amd="/home/psteger/astro/amd/";
  std::string folder_snaps = folder_amd+"snap/";
  std::string folder_amateur = folder_amd+"amateur/";
  std::string folder_output = folder_amd+"output/";

  if(where=="amd")
    return folder_amd;
  else if(where=="snaps")
    return folder_snaps;
  else if(where=="amateur")
    return folder_amateur;
  else if(where=="output")
    return folder_output;
  else
    {
      std::cout << "Folder " << where << " not found, returning folder of amd!";
      return folder_amd;
    }
}

/* \brief Returns string of an AMATEUR snapshot */
/**
 * Returns the full path to an AMATEUR snapshot
 * @param SnapNo: ID of snapshot
 * @return std::string full_path
 */
std::string Snaps(unsigned SnapNo){
  std::string snaps [18]= {

    "tarkin_5726_10x_snap_302", "tarkin_25174_CSF_10x_snap_008", "tarkin_25174_CSF_10x_snap_009",

    "tarkin_13309_CSF_45x_snap_002", "tarkin_13309_CSF_45x_snap_058 ", "tarkin_13309_CSF_45x_snap_118",
    "tarkin_13309_CSF_45x_snap_152", "tarkin_13309_CSF_45x_snap_179", "tarkin_13309_CSF_45x_snap_200",
    "tarkin_13309_CSF_45x_snap_211", "tarkin_13309_CSF_45x_snap_225", "tarkin_13309_CSF_45x_snap_257",
    "tarkin_13309_CSF_45x_snap_279", "tarkin_13309_CSF_45x_snap_299", "tarkin_13309_CSF_45x_snap_302",

    "tarkin_21926_CSF_45x_snap_302", "tarkin_25174_CSF_45x_snap_289", "tarkin_25174_CSF_45x_snap_302"
  };

  return snaps[SnapNo];
}
