/**************************************************************************
 *   Copyright (C) 2008 by Pascal Stephan Philipp Steger                   *
 *   psteger@phys.ethz.ch                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, ma  02111-1307, USA.             *
 ***************************************************************************/

/*!
 * \file AnalyzeSnap.cpp
 * \brief Analyzes a given snapshot with HaloProperties, for all particle types
 */

#include <cassert>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <string>
#include <vector>

#include "SystemCharacteristics.h"
#include "DataStruct.h"
#include "ReadGadget.h"
#include "HaloProperties.h"
#include "HDFIO.h"

//unsigned ParticleType;
std::vector < double > Vhp_PosCM;
std::vector < double > Vhp_PosMB;
std::vector < double > Vhp_VelCM;
std::vector < double > Vhp_Rvir;
std::vector < double > Vhp_Mvir;
std::vector < std::vector < double > > Vhp_Mass(4);
std::vector < std::vector < double > > Vhp_LambdaPrime(4);
std::vector < std::vector < double > > Vhp_J(4);
// std::vector < std::vector < double > > Vhp_EVmax(4);
std::vector < std::vector < double > > Vhp_EVa(4);
std::vector < std::vector < double > > Vhp_EVb(4);
std::vector < std::vector < double > > Vhp_EVc(4);
std::vector < std::vector < double > > Vhp_Eigenvalues(4);
// std::vector < std::vector < double > > Vhp_EW(4);
std::vector < unsigned > Vhp_HaloParticlesCount;
std::vector < std::vector < unsigned > > Vhp_HaloParticlesTypesCount(4);

std::vector < double > Vahf_npart;
std::vector < double > Vahf_nvpart;
std::vector < double > Vahf_ovdens;
std::vector < double > Vahf_sigV;
std::vector < double > Vahf_J;
std::vector < double > Vahf_EW;
std::vector < double > Vahf_EVa;
std::vector < double > Vahf_EVb;
std::vector < double > Vahf_EVc;
std::vector < double > Vahf_Ekin;
std::vector < double > Vahf_Epot;
std::vector < double > Vahf_xc;

/**
 * conversion between little/big endian
 * @param v
 * @return
 */
template < typename T > T byteorder(T v)
{
  T val;
  (reinterpret_cast < unsigned char *>(&val))[3] =
    (reinterpret_cast < unsigned char *>(&v))[0];
  (reinterpret_cast < unsigned char *>(&val))[2] =
    (reinterpret_cast < unsigned char *>(&v))[1];
  (reinterpret_cast < unsigned char *>(&val))[1] =
    (reinterpret_cast < unsigned char *>(&v))[2];
  (reinterpret_cast < unsigned char *>(&val))[0] =
    (reinterpret_cast < unsigned char *>(&v))[3];
  return val;
}

// reads the ahfstep output files and pushes the values onto vectors
void Storeahf(std::fstream & ahfhalos)
{
  unsigned ahf_npart = 0;
  unsigned ahf_nvpart = 0;
  float ahf_Xc = 0.0f;
  float ahf_Yc = 0.0f;
  float ahf_Zc = 0.0f;
  float ahf_VXc = 0.0f;
  float ahf_VYc = 0.0f;
  float ahf_VZc = 0.0f;
  float ahf_Mvir = 0.0f;
  float ahf_Rvir = 0.0f;
  float ahf_Vmax = 0.0f;
  float ahf_Rmax = 0.0f;
  float ahf_sigV = 0.0f;
  float ahf_lambda = 0.0f;
  float ahf_Jx = 0.0f;
  float ahf_Jy = 0.0f;
  float ahf_Jz = 0.0f;
  float ahf_a = 0.0f;
  float ahf_Eax = 0.0f;
  float ahf_Eay = 0.0f;
  float ahf_Eaz = 0.0f;
  float ahf_b = 0.0f;
  float ahf_Ebx = 0.0f;
  float ahf_Eby = 0.0f;
  float ahf_Ebz = 0.0f;
  float ahf_c = 0.0f;
  float ahf_Ecx = 0.0f;
  float ahf_Ecy = 0.0f;
  float ahf_Ecz = 0.0f;
  float ahf_ovdens = 0.0f;
  float ahf_Redge = 0.0f;
  int ahf_nbins = 0;
  float ahf_Ekin = 0.0f;
  float ahf_Epot = 0.0f;
  float ahf_mbp_offset = 0.0f;
  float ahf_com_offset = 0.0f;
  float ahf_r2 = 0.0f;
  float ahf_lambdaE = 0.0f;

  ahfhalos >> ahf_npart   >> ahf_nvpart   >> ahf_Xc   >> ahf_Yc   >> ahf_Zc
	   >> ahf_VXc   >> ahf_VYc   >> ahf_VZc
	   >> ahf_Mvir >> ahf_Rvir
	   >> ahf_Vmax   >> ahf_Rmax
	   >> ahf_sigV
	   >> ahf_lambda
	   >> ahf_Jx   >> ahf_Jy   >> ahf_Jz
	   >> ahf_a   >> ahf_Eax   >> ahf_Eay   >> ahf_Eaz
	   >> ahf_b   >> ahf_Ebx   >> ahf_Eby   >> ahf_Ebz
	   >> ahf_c   >> ahf_Ecx   >> ahf_Ecy   >> ahf_Ecz
	   >> ahf_ovdens
	   >> ahf_Redge
	   >> ahf_nbins
	   >> ahf_Ekin   >> ahf_Epot 
	   >> ahf_mbp_offset >> ahf_com_offset 
	   >> ahf_r2 
	   >> ahf_lambdaE;

  Vahf_xc.push_back(ahf_Xc);  Vahf_xc.push_back(ahf_Yc);  Vahf_xc.push_back(ahf_Zc);
  Vahf_npart.push_back(ahf_npart);  Vahf_nvpart.push_back(ahf_nvpart);
  Vahf_ovdens.push_back(ahf_ovdens);
  Vahf_sigV.push_back(ahf_sigV);
  Vahf_J.push_back(ahf_Jx);  Vahf_J.push_back(ahf_Jy);  Vahf_J.push_back(ahf_Jz);
  Vahf_EW.push_back(ahf_a);  Vahf_EW.push_back(ahf_b);  Vahf_EW.push_back(ahf_c);
  Vahf_EVa.push_back(ahf_Eax);  Vahf_EVa.push_back(ahf_Eay);  Vahf_EVa.push_back(ahf_Eaz);
  Vahf_EVb.push_back(ahf_Ebx);  Vahf_EVb.push_back(ahf_Eby);  Vahf_EVb.push_back(ahf_Ebz);
  Vahf_EVc.push_back(ahf_Ecx);  Vahf_EVc.push_back(ahf_Ecy);  Vahf_EVc.push_back(ahf_Ecz);
  Vahf_Ekin.push_back(ahf_Ekin);  Vahf_Epot.push_back(ahf_Epot);
}

void
WriteHDF5(std::string filename, double Boxsize, double Redshift,
	  double HaloTotCount)
{
  std::cout << " * Writing HaloProperties into HDF5...";
  HDFCreateFile(filename);
  HDFCreateGroup(filename, "Header");
  HDFWriteGroupAttribute(filename, "Header", "Boxsize", Boxsize);
  HDFWriteGroupAttribute(filename, "Header", "Redshift", Redshift);
  HDFWriteGroupAttribute(filename, "Header", "NumHalos", HaloTotCount);
  HDFWriteDataset(filename, "hp_HaloParticlesCount", Vhp_HaloParticlesCount);
  HDFWriteDatasetVector(filename, "hp_PosCM", Vhp_PosCM);
  HDFWriteDatasetVector(filename, "hp_PosMB", Vhp_PosMB);
  HDFWriteDatasetVector(filename, "hp_VelCM", Vhp_VelCM);
  HDFWriteDataset(filename, "hp_Rvir", Vhp_Rvir);
  HDFWriteDataset(filename, "hp_Mvir", Vhp_Mvir);
  std::string count[4]={"0","1","2","3"};
  for(unsigned i=0; i<4; ++i){
    HDFWriteDataset(filename, "hp_LambdaPrime_"+count[i], Vhp_LambdaPrime.at(i));
    HDFWriteDataset(filename, "hp_Mass_"+count[i], Vhp_Mass.at(i));
    HDFWriteDatasetVector(filename, "hp_J_"+count[i], Vhp_J.at(i));
    HDFWriteDatasetVector(filename, "hp_EVa_"+count[i], Vhp_EVa.at(i));
    HDFWriteDatasetVector(filename, "hp_EVb_"+count[i], Vhp_EVb.at(i));
    HDFWriteDatasetVector(filename, "hp_EVc_"+count[i], Vhp_EVc.at(i));
    HDFWriteDatasetVector(filename, "hp_EW_"+count[i], Vhp_Eigenvalues.at(i));
    HDFWriteDataset(filename, "hp_HaloParticlesTypesCount_"+count[i], Vhp_HaloParticlesTypesCount.at(i));
  }
  std::cout << "done!" << std::endl;

  std::cout << " * Writing selected ahf results to HDF5...";
  HDFWriteDataset(filename, "ahf_npart", Vahf_npart);
  HDFWriteDatasetVector(filename, "ahf_xc", Vahf_xc);
  HDFWriteDataset(filename, "ahf_nvpart", Vahf_nvpart);
  HDFWriteDataset(filename, "ahf_ovdens", Vahf_ovdens);
  HDFWriteDataset(filename, "ahf_sigV", Vahf_sigV);
  HDFWriteDatasetVector(filename, "ahf_J", Vahf_J);
  HDFWriteDatasetVector(filename, "ahf_EW", Vahf_EW);
  HDFWriteDatasetVector(filename, "ahf_EVa", Vahf_EVa);
  HDFWriteDatasetVector(filename, "ahf_EVb", Vahf_EVb);
  HDFWriteDatasetVector(filename, "ahf_EVc", Vahf_EVc);
  HDFWriteDataset(filename, "ahf_Ekin", Vahf_Ekin);
  HDFWriteDataset(filename, "ahf_Epot", Vahf_Epot);
  std::cout << "done!" << std::endl;
}

/* \brief Return offsets of particle types inside snapshot. */
/* Get the particle ID offsets of the different particle types
 * \param ParticleIDOffset, unsigned*: where the offsets are stored
 * \param npart, unsigned*: counts of particles types
 */
void GetOffsets(unsigned* ParticleIDOffsets, unsigned* npart)
{
  std::cout << "offsets: ";
  for (int x = 0; x < 6; ++x) {
    ParticleIDOffsets[x] = std::accumulate(&npart[0], &npart[x], 0);
    std::cout << ParticleIDOffsets[x] << " ";
  }
  std::cout << std::endl;
}

/* \brief Analysis of one single snapshot file */
/*
 * Analyzes a single snapshot file.
 * \param isnap unsigned snapshot ID
 * \return void
 */
void AnalyzeSnap(unsigned isnap)
{
  std::string SnapshotString = Snaps(isnap);

  std::cout << " * Getting particle numbers..." << std::endl;
  unsigned TotalNOParticles;
  unsigned npart[6];
  unsigned id_min[6];
  unsigned id_max[6];
  double Redshift;
  double Boxsize;
  double Masses[6];

  std::string SnapshotFilename = Folder("snaps") + Snaps(isnap);
  get_particle_number(SnapshotFilename.c_str(), id_min, id_max, Masses,
		      npart, TotalNOParticles, Redshift, Boxsize);

  std::cout << " * Opening ahf_out_particles...";
  std::string SnapshotParticlesFilename =
    Folder("output") + Snaps(isnap) + "/ahf_out_particles";
  std::ifstream SnapshotParticles;
  SnapshotParticles.open(SnapshotParticlesFilename.c_str(),
			 std::ios_base::in | std::ios_base::binary);
  std::cout << "done!" << std::endl;

  std::cout << " * Getting number of halos: ";
  unsigned HaloTotCount = 0;
  SnapshotParticles >> HaloTotCount;
  std::cout << HaloTotCount << " halos totally." << std::endl;

  std::cout << " * Allocating memory...";

  float *ftemp = new float[3 * TotalNOParticles];
  int *id = new int[TotalNOParticles];
  double *pos = new double[3 * TotalNOParticles];
  double *vel = new double[3 * TotalNOParticles];
  double *mass = new double[TotalNOParticles];	//, * temp, * u, * rho;

  std::cout << "done!" << std::endl;

  std::cout << " * Reading data blocks..." << std::endl;
  FILE *SnapshotFile = 0;
  SnapshotFile = fopen(SnapshotFilename.c_str(), "r");
  int n = 0;
  n = read_gadget_1((int *) id, "ID  ", SnapshotFile);

  n = read_gadget_3(ftemp, "POS ", SnapshotFile);
  for (int ii = 0; ii < 3 * n; ++ii)
    pos[ii] = ftemp[ii];

  n = read_gadget_3(ftemp, "VEL ", SnapshotFile);
  for (int ii = 0; ii < 3 * n; ++ii)
    vel[ii] = ftemp[ii];

  n = read_gadget_1(ftemp, "MASS", SnapshotFile);
  for (int ii = 0; ii < n; ++ii)
    mass[ii] = ftemp[ii];

  delete[] ftemp;
  // n = read_gadget_1( ( float * ) temp, "TEMP", SnapshotFile );
  // n = read_gadget_1( ( float * ) u,    "U   ", SnapshotFile );
  // n = read_gadget_1( ( float * ) rho,  "RHO ", SnapshotFile );
  fclose(SnapshotFile);
  std::cout << "done!" << std::endl << std::endl;


  std::cout << " * Getting particle offsets... ";
  unsigned ParticleIDOffsets[6];
  GetOffsets(&ParticleIDOffsets[0], &npart[0]);

  std::cout << " * Generating particle index map...";
  std::cout.flush();
  std::map < int, unsigned > DoubleIndexMap;
  for (unsigned j = 0; j < TotalNOParticles; ++j)
    DoubleIndexMap.insert(std::make_pair(id[j], j));
  std::cout << "done!" << std::endl;

  std::cout << " * Writing halo data into HDF5...";
  // std::string now = "mkdir " + Folder("output") + SnapshotString;
  // RunCommand(now);
  std::string now = "";
  std::string fn_out = Folder("output") + SnapshotString + "/snapshot_halos.hdf5";
  HDFCreateFile(fn_out);
  HDFCreateGroup(fn_out, "Header");
  HDFCreateGroup(fn_out, "Halos");
  HDFWriteGroupAttribute(fn_out, "Header", "Boxsize", Boxsize);
  HDFWriteGroupAttribute(fn_out, "Header", "Redshift", Redshift);
  HDFWriteGroupAttribute(fn_out, "Header", "NumHalos", HaloTotCount);
  std::cout << "done!" << std::endl;

  std::cout << " * Opening ahf_out_halos...";
  std::string ahf_halos = Folder("output") + SnapshotString + "/ahf_out_halos";
  std::fstream ahfhalos(ahf_halos.c_str(), std::ios::in);
  if (!ahfhalos.is_open()) {
    std::cerr << " * ahf_out_halos could not be opened!" << std::endl;
    return;
  }
  std::cout << "done." << std::endl;

  std::cout << " * Running through cluster: " << std::endl;
  unsigned HaloPopulation = 0;
  unsigned HaloNumber = 0;
  double HaloMass = 0.0;

  // Loop over all halos: get particles, build HP, determine properties
  for (unsigned ihalo = 0; ihalo < HaloTotCount; ++ihalo) {
    SnapshotParticles >> HaloNumber;
    std::cout << "Halo " << HaloNumber << std::endl;
    SnapshotParticles >> HaloPopulation;
    std::cout << "Halo Population = " << HaloPopulation << std::endl;
    SnapshotParticles >> HaloMass;
    std::cout << "Halo Mass = " << HaloMass << std::endl;
    std::cout << " * * Getting index positions of particles in the cluster..."
	      << std::flush;

    int *ParticleIndexID = new int[HaloPopulation];
    int *ParticleIndexType = new int[HaloPopulation];
    double *ParticleIndexMass = new double[HaloPopulation];

    int ParticleID = 0;
    int ParticleType = 0;
    double ParticleMass = -1.0;
    for (unsigned i = 0; i < HaloPopulation; ++i) {
      SnapshotParticles >> ParticleID;
      //std::cout << "ParticleID = " << ParticleID << std::endl;
      SnapshotParticles >> ParticleType;
      //std::cout << "ParticleType = " << ParticleType << std::endl;
      SnapshotParticles >> ParticleMass;
      //std::cout << "ParticleMass = " << ParticleMass << std::endl;
      ParticleIndexID[i] = ParticleID;
      ParticleIndexType[i] = ParticleType;
      ParticleIndexMass[i] = ParticleMass;
    }
    std::cout << "done." << std::endl;

    std::cout << " * * Calculating properties of halo " << ihalo <<
      std::endl;
    char buffer[10];
    sprintf(buffer, "%d", ihalo);
    std::string datas = buffer;
    std::string datasp = "Cluster_Pos_" + datas;
    std::string datasv = "Cluster_Vel_" + datas;
    std::string datasm = "Cluster_Mass_" + datas;

    std::cout << " * * Allocating space for halo..." << std::flush;
    double *pos2 = new double[3 * HaloPopulation];
    double *vel2 = new double[3 * HaloPopulation];
    double *mass2 = new double[HaloPopulation];
    std::cout << "done!" << std::endl;
    std::cout << " * * Sorting pos, vel and mass according to particle type..." << std::endl;
    unsigned particleCounter[5] = { 0, 0, 0, 0, 0 };
    unsigned HaloParticleIDOffsets[5] = { 0, 0, 0, 0, 0 };
    unsigned HPIDO[5] = { 0, 0, 0, 0, 0 };
    std::cout << " * * First step: determine particle ID offsets for this specific halo...";
    for (unsigned k = 0; k < HaloPopulation; ++k)
      HPIDO[ParticleIndexType[k]]++;
    for (int x = 0; x < 5; ++x)
      HaloParticleIDOffsets[x] = std::accumulate(&HPIDO[0], &HPIDO[x], 0);
    std::cout << "done!" << std::endl;

    Vhp_HaloParticlesCount.push_back(HaloPopulation);

    for (unsigned k = 0; k < HaloPopulation; ++k) {
      // running through all particles inside this halo

      // putting entry in new list at right position:
      // we know the particle offset (inside halo) and the number of particles accounted so far
      unsigned ptype = ParticleIndexType[k];
      mass2[HaloParticleIDOffsets[ptype] + particleCounter[ptype]] = mass[DoubleIndexMap[ParticleIndexID[k]]];
      for (unsigned i = 0; i < 3; ++i) {
	pos2[3 * (HaloParticleIDOffsets[ptype] + particleCounter[ptype]) + i] = pos[3*DoubleIndexMap[ParticleIndexID[k]]+i];
	vel2[3 * (HaloParticleIDOffsets[ptype] + particleCounter[ptype]) + i] = vel[3*DoubleIndexMap[ParticleIndexID[k]]+i];
      }
      ++particleCounter[ptype];
    }
    std::cout << "   ...done!" << std::endl;

    std::cout << " * * Generating starting and size vectors...";
    unsigned istart[4] = { HaloParticleIDOffsets[0],
			   HaloParticleIDOffsets[0],
			   HaloParticleIDOffsets[1],
			   HaloParticleIDOffsets[4]};
    unsigned isize[4] = { HaloPopulation,
			  HPIDO[0],
			  HPIDO[1]+HPIDO[2]+HPIDO[3],
			  HPIDO[4]};
    for(unsigned ppp = 0; ppp < 4; ++ppp)
      Vhp_HaloParticlesTypesCount.at(ppp).push_back(HPIDO[ppp]);
    std::cout << "done!";

    // cosmology
    double Omega_M = 0.3;
    double h = 0.7;
    //double rhobox = 1.8791E-29 * Omega_M; // in gm/cm^3
    double rhobox = 2.7757819e-8 * Omega_M / (h * h);	//in 10^10 msun/(h kpc)^3
    rhobox = 0.0;	// gives loops over all particles, independent of overdensity
    double Rvir = -1.0;
    double Mvir = -1.0;
    double Mtot = -1.0;
    Vector3 xcm;
    Vector3 vcm;
    Vector3 xmb;

    for (unsigned ppp = 0; ppp < 4; ++ppp) {
      std::cout << " * * Creating halo...";
      HaloProperties halo = HaloProperties(&pos2[istart[ppp]], &vel2[istart[ppp]], &mass2[istart[ppp]], isize[ppp], Redshift);
      std::cout << "done!" << std::endl;
#if 0 // exclude unbound particles in this step?
      std::vector < bool > exc(HaloPopulation);
      std::vector < bool > excs(HaloPopulation);
      std::cout << " * * Cleaning unbound particles..." << std::endl;
      halo.CleanUnboundExc(Boxsize, exc);
      halo.CleanUnboundSimple(Boxsize, excs);
      std::cout << "done!" << std::endl;

      std::cout << " * * Pushing back exclusion vectors...";
      std::vector < int > exci(HaloPopulation);
      for (unsigned i = 0; i < HaloPopulation; ++i)
	exci.at(i) = int (exc.at(i));
      HDFWriteDataset(fn_out, datasx, exci);
      for (unsigned i = 0; i < HaloPopulation; ++i)
	exci.at(i) = int (excs.at(i));
      HDFWriteDataset(fn_out, datasxs, exci);
      std::cout << "done!" << std::endl;

      std::cout.flush();
#else
      //change all following calculations such that they have an exclusion list available
#endif
      std::cout << " * * Computing total mass...";

      Mtot = halo.ComputeTotalMass();
      std::cout << Mtot << ", done." << std::endl;
      if (ppp == 0) {
	std::cout << " * * Computing center of mass...";

	halo.ComputeCM(Boxsize, xcm);
	std::cout << xcm << ", done." << std::endl;

	std::cout << " * * Computing center velocity...";
	halo.ComputeCenterVel(vcm);
	std::cout << vcm << ", done." << std::endl;

	std::cout << " * * Computing position of most bound particle..." << std::flush;
	halo.ComputeMB(Boxsize, xmb);
	std::cout << xmb << ", done." << std::endl;

	std::cout << " * * Centering on most bound particle...";
	halo.CenterOnMB(Boxsize);
	halo.CenterVel();
	std::cout << "done!" << std::endl;

	std::cout << " * * Computing virial properties...";
	halo.ComputeVirialProperties(rhobox, Mvir, Rvir);
	std::cout << "done." << std::endl;

	for (unsigned j = 0; j < 3; Vhp_PosCM.push_back(xcm(j)), ++j);
	for (unsigned j = 0; j < 3; Vhp_VelCM.push_back(vcm(j)), ++j);
	for (unsigned j = 0; j < 3; Vhp_PosMB.push_back(xmb(j)), ++j);
	Vhp_Mvir.push_back(Mvir);
	Vhp_Rvir.push_back(Rvir);
      }

      std::cout << " * * Computing angular momentum..." << std::flush;
      Vector3 J;
      halo.ComputeAngularMomentum(J);
      std::cout << "done." << std::endl;

      std::cout << " * * Computing lambda'..." << std::flush;
      double lambda = 0.0;
      halo.ComputeLambdaPrime(lambda, Mvir, Rvir);
      std::cout << lambda << ", done." << std::endl;

      std::cout << " * * Computing Axes..." << std::flush;
      Vector3 Eigenvalues;
      std::vector<Vector3> Eigenvectors;
      halo.ComputeMajorAxes( Eigenvalues, Eigenvectors );
      std::cout << "done." << std::endl;

      std::cout << " * * Pushing back HaloProperties outputs...";
      for (unsigned j = 0; j<3; ++j) {
	Vhp_J.at(ppp).push_back(J(j));
	Vhp_EVa.at(ppp).push_back((Eigenvectors.at(0))(j));
	Vhp_EVb.at(ppp).push_back((Eigenvectors.at(1))(j));
	Vhp_EVc.at(ppp).push_back((Eigenvectors.at(2))(j));
	Vhp_Eigenvalues.at(ppp).push_back((Eigenvalues)(j));
      }
      Vhp_LambdaPrime.at(ppp).push_back(lambda);
      Vhp_Mass.at(ppp).push_back(Mtot);
      std::cout << "done." << std::endl;
    }
    // step through all of the different particles.

    std::cout << " * * Deleting arrays from ahf output...";
    delete[] ParticleIndexID;
    delete[] ParticleIndexType;
    delete[] ParticleIndexMass;
    std::cout << "done!" << std::endl;

    std::cout << " * * Deleting arrays from halo2...";
    delete[] pos2;
    delete[] vel2;
    delete[] mass2;
    std::cout << "done!" << std::endl;

  }
  //next halo
  delete[] id;
  delete[] pos;
  delete[] vel;
  delete[] mass;

  std::cout << " * * Pushing back ahf outputs...";
  Storeahf(ahfhalos);
  ahfhalos.close();
  std::cout << "done!" << std::endl;

  SnapshotParticles.close();
  fn_out = Folder("output") + SnapshotString + "/extra.hdf5";
  WriteHDF5(fn_out, Boxsize, Redshift, HaloTotCount);

  std::cout << " * Properties extracted." << std::endl << std::endl;
  return;
}
