//copyright 2008 Oliver Hahn

/*!
 * \file TidalField.cpp
 * \brief Implements the -t: Computation of the tidal field.
 */

//#define WITH_MPI
//#include "mpi++.h"

#include <unistd.h>
#include <sstream>

#include "TidalField.h"
#include "HDFIO.h"
#include "PoissonSolver.h"
#include "SystemCharacteristics.h"


//in kpc, not Mpc
const float G_const = 43011.7902;

float stencil11_1[ 11 ] = { -7.9365079365e-04,
                            9.9206349206e-03,
                            -5.9523809524e-02,
                            2.3809523810e-01,
                            -8.3333333333e-01,
                            0.0,
                            8.3333333333e-01,
                            -2.3809523810e-01,
                            5.9523809524e-02,
                            -9.9206349206e-03,
                            7.9365079365e-04 };
float stencil11_2[ 11 ] = { 3.1746031746e-04,
                            -4.9603174603e-03,
                            3.9682539683e-02,
                            -2.3809523810e-01,
                            1.6666666667e+00,
                            -2.9272222222e+00,
                            1.6666666667e+00,
                            -2.3809523810e-01,
                            3.9682539683e-02,
                            -4.9603174603e-03,
                            3.1746031746e-04 };
float stencil9_1[ 9 ] = { 3.5714285714e-03,
                          -3.8095238095e-02,
                          0.2000000000,
                          -0.8000000000,
                          0.0,
                          0.8000000000,
                          -0.2000000000,
                          3.8095238095e-02,
                          -3.5714285714e-03 };
float stencil9_2[ 9 ] = { -1.7857142857e-03,
                          2.5396825397e-02,
                          -2.0000000000e-01,
                          1.6000000000e+00,
                          -2.8472222222e+00,
                          1.6000000000e+00,
                          -2.0000000000e-01,
                          2.5396825397e-02,
                          -1.7857142857e-03 };
float stencil7_1[ 7 ] = {	-0.0166666667,
				0.1500000000,
				-0.7500000000,
				0.0,
				0.7500000000,
				-0.1500000000,
				0.0166666667 };
float stencil7_2[ 7 ] = { 0.0111111111,
                          -0.1500000000,
                          1.5000000000,
                          -2.7222222222,
                          1.5000000000,
                          -0.1500000000,
                          0.0111111111 };

float stencil5_1[ 5 ] = { 0.0833333333, -0.6666666667, 0.0, 0.6666666667, -0.0833333333 };
float stencil5_2[ 5 ] = { -0.0833333333, 1.3333333333, -2.5, 1.3333333333, -0.0833333333 };

float stencil3_1[ 3 ] = { -0.5,
                          0.0,
                          0.5 };
float stencil3_2[ 3 ] = { 1.0,
                          -2.0,
                          1.0 };

/* @brief Choose a stencil. */
/*
 * Choose a stencil
 * @return void
 */
void
ScalarField::ChooseStencil( void ) {
  switch ( m_nstencil ) {

  case 3:
    m_pStencil1 = stencil3_1;
    m_pStencil2 = stencil3_2;
    break;

  case 5:
    m_pStencil1 = stencil5_1;
    m_pStencil2 = stencil5_2;
    break;

  case 7:
    m_pStencil1 = stencil7_1;
    m_pStencil2 = stencil7_2;
    break;

  case 9:
    m_pStencil1 = stencil9_1;
    m_pStencil2 = stencil9_2;
    break;

  case 11:
    m_pStencil1 = stencil11_1;
    m_pStencil2 = stencil11_2;
    break;


  default:
    std::cerr << " * * ERROR: unsupported finite difference scheme in ScalarField::ChooseStencil!" << std::endl;
    abort();
  }

}

/*
 * checks whether a file does exist
 * @param filename
 * @return bool true or false
 */
bool DoesFileExist( char *filename ) {
  bool flag = false;
  std::fstream fin( filename, std::ios::in );
  if ( fin.is_open() )
    flag = true;
  fin.close();

  return flag;
}

/* @brief Put clound in cell */
/*
 * Puts cloud in cell environment
 * @param npart number of particles
 * @param coord positions of particles
 * @param wpar mass ("weight") of particles
 */
template < typename T >
void ScalarField::put_CIC( unsigned npart, T *coord, float *wpar ) {

  unsigned ix, iy, iz, ix1, iy1, iz1;
  float x, y, z;
  float dx, dy, dz, dyw;
  float tx, ty, tz, tyw;

  static bool bInitialized( false );

  if ( !bInitialized ) {
    bInitialized = true;
    std::cout << " * * initializing density field with -1...";
    for ( ix = 0; ix < m_nx; ++ix )
      for ( iy = 0; iy < m_ny; ++iy )
	for ( iz = 0; iz < m_nz; ++iz )
	  m_data( ix, iy, iz ) = -1.0;
    std::cout << "done!" << std::endl;
  }

  for ( unsigned i = 0, i3=0; i < npart; ++i, i3=3*i ) {
    x = coord[ i3 + 0 ];
    y = coord[ i3 + 1 ];
    z = coord[ i3 + 2 ];

    ix = unsigned ( x );
    iy = unsigned ( y );
    iz = unsigned ( z );

    dx = x - ( float ( ix ) );
    dy = y - ( float ( iy ) );
    dz = z - ( float ( iz ) );

    ix %= m_nx;
    iy %= m_ny;
    iz %= m_nz;

    tx = 1.0 - dx;
    ty = 1.0 - dy;
    tz = 1.0 - dz;

    tyw = ty * wpar[ i ];
    dyw = dy * wpar[ i ];

    ix1 = ( ix + 1 ) % m_nx;
    iy1 = ( iy + 1 ) % m_ny;
    iz1 = ( iz + 1 ) % m_nz;

    m_data( ix, iy, iz ) += tz * tx * tyw;
    m_data( ix, iy1, iz ) += tz * tx * dyw;
    m_data( ix, iy, iz1 ) += dz * tx * tyw;
    m_data( ix, iy1, iz1 ) += dz * tx * dyw;

    m_data( ix1, iy, iz ) += tz * dx * tyw;
    m_data( ix1, iy1, iz ) += tz * dx * dyw;
    m_data( ix1, iy, iz1 ) += dz * dx * tyw;
    m_data( ix1, iy1, iz1 ) += dz * dx * dyw;

  }
}

/* @brief diff2atCIC */
/**
 * diff2atCIC
 * @param Coord: list of coordinates
 * @param nPoints: number of points in Coord where we want to know the tensor
 * @param t_ij: tensor
 * @return void
 */
void
ScalarField::diff2atCIC( float *Coord, unsigned nPoints, std::vector< Matrix33 > &t_ij ) {

  ChooseStencil();

  for ( unsigned ip = 0; ip < nPoints; ++ip ) {
    int ix = int ( Coord[ 3 * ip + 0 ] );
    int iy = int ( Coord[ 3 * ip + 1 ] );
    int iz = int ( Coord[ 3 * ip + 2 ] );

    if ( ix > int ( m_nx ) ) {
      std::cerr << " * * ERROR: index out of bounds! " << Coord[ 3 * ip ] << std::endl;
      ix = m_nx;
    }

    int
      ix1 = ( ix + 1 ) % m_nx,
      iy1 = ( iy + 1 ) % m_ny,
      iz1 = ( iz + 1 ) % m_nz;

    float x = ( ( float ) Coord[ 3 * ip + 0 ] );
    float y = ( ( float ) Coord[ 3 * ip + 1 ] );
    float z = ( ( float ) Coord[ 3 * ip + 2 ] );

    float
      cic_dx = x - ( float ) ix;
    float cic_dy = y - ( float ) iy;
    float cic_dz = z - ( float ) iz;
    float cic_tx = 1.0 - cic_dx;
    float cic_ty = 1.0 - cic_dy;
    float cic_tz = 1.0 - cic_dz;

    float xyz = cic_tx * cic_ty * cic_tz;
    float Xyz = cic_dx * cic_ty * cic_tz;
    float xYz = cic_tx * cic_dy * cic_tz;
    float XYz = cic_dx * cic_dy * cic_tz;
    float xyZ = cic_tx * cic_ty * cic_dz;
    float XyZ = cic_dx * cic_ty * cic_dz;
    float xYZ = cic_tx * cic_dy * cic_dz;
    float XYZ = cic_dx * cic_dy * cic_dz;

    Matrix33 t;

    for ( int i = 0; i < 3; ++i )
      for ( int j = 0; j < 3; ++j ) {

	float
	  f_ijk, f_Ijk, f_iJk, f_IJk,
	  f_ijK, f_IjK, f_iJK, f_IJK;

	float
	  dy_ijk, dy_Ijk, dy_iJk, dy_IJk,
	  dy_ijK, dy_IjK, dy_iJK, dy_IJK;

	f_ijk = this->diff2( ix, iy, iz, i, j );
	f_Ijk = this->diff2( ix1, iy, iz, i, j );
	f_iJk = this->diff2( ix, iy1, iz, i, j );
	f_IJk = this->diff2( ix1, iy1, iz, i, j );
	f_ijK = this->diff2( ix, iy, iz1, i, j );
	f_IjK = this->diff2( ix1, iy, iz1, i, j );
	f_iJK = this->diff2( ix, iy1, iz1, i, j );
	f_IJK = this->diff2( ix1, iy1, iz1, i, j );

	dy_ijk = f_ijk * xyz;
	dy_Ijk = f_Ijk * Xyz;
	dy_iJk = f_iJk * xYz;
	dy_IJk = f_IJk * XYz;
	dy_ijK = f_ijK * xyZ;
	dy_IjK = f_IjK * XyZ;
	dy_iJK = f_iJK * xYZ;
	dy_IJK = f_IJK * XYZ;

	t( i, j ) = dy_ijk + dy_Ijk + dy_iJk + dy_IJk + dy_ijK + dy_IjK + dy_iJK + dy_IJK;
      }
    t_ij.push_back( t );
  }
}

/* @brief Store tensor field. */
/**
 * store tensor field to HDF5
 * @param filename: path to output file
 * @param nPoints: number of points
 * @param coordinates: evaluation points
 * @param aTensorField: tensor field that should be evaluated
 * @param SmoothingMassScale: smoothing scale
 */
void StoreTensorField( std::string filename, unsigned nPoints, const std::vector<float>& coordinates, const std::vector< Matrix33 > &aTensorField, float SmoothingMassScale ) {

  std::vector< std::vector<float> > tensor;
  std::vector<float> eigenvalues,eigenvector1,eigenvector2,eigenvector3;
  std::cout << " * * Writing data for " << nPoints << " points to file " << filename.c_str() << "..." << std::endl;

  for ( unsigned i = 0; i < nPoints; ++i ) {
    // tensor and trace-free tensor
    std::vector<Vector3> V;
    Matrix33 A;
    Vector3 lambda;

    std::vector<float> tensortemp, evaltemp, evecttemp;
    for ( unsigned k = 0; k < 3; ++k )
      for ( unsigned l = 0; l <= k; ++l )
	tensortemp.push_back( aTensorField[ i ] ( l, k ) );

    A = aTensorField[ i ];
		
    A.Eigen( lambda, V );


    for ( unsigned j = 0; j < 3; ++j ) {
			
      eigenvalues.push_back( lambda( j ) );
      eigenvector1.push_back( (V.at(0))(j) );
      eigenvector2.push_back( (V.at(1))(j) );
      eigenvector3.push_back( (V.at(2))(j) );
    }

    tensor.push_back( tensortemp );
		
  }

  HDFWriteDatasetVector( filename, "Coordinates", coordinates );
  HDFWriteDataset2D( filename, "TensorField", tensor );
  HDFWriteDatasetVector( filename, "Eigenvector_1", eigenvector1 );
  HDFWriteDatasetVector( filename, "Eigenvector_2", eigenvector2 );
  HDFWriteDatasetVector( filename, "Eigenvector_3", eigenvector3 );
  HDFWriteDatasetVector( filename, "Eigenvalues", eigenvalues );
}


/* @brief Computes the tidal field from a given mass distribution. */
/**
 * computes the tidal field from a given mass distribution
 * @param snaphdf5: a snapshot file, converted by AnalyzeSnap
 * @param N: the length of the density mesh
 * @param Radius: the length scale used for smoothing
 * @param extrahdf5: file containing the CMs of the halos
 * @param tensorhdf5: output file for the tensor components
 * @return void
 */
void TidalField( std::string snaphdf5, unsigned N, double Radius, std::string extrahdf5, std::string tensorhdf5 ) {

  std::cout << "TidalField v1.1 - by O. Hahn, P. Steger (ETH Zurich)" << std::endl;
  std::cout << "----------------------------------------------------------" << std::endl << std::endl;

  unsigned nParticles = 0;
  float boxsize = 0.0f;
  std::vector<float> pmass;
  std::vector<float> ppos;
  std::cout << " * Reading particle properties...";
  // attention: what type of particles?
  HDFReadGroupAttribute( snaphdf5, "Header", "NumParticles", nParticles );
  HDFReadGroupAttribute( snaphdf5, "Header", "Boxsize", boxsize );
  HDFReadDataset( snaphdf5, "Data_Mass", pmass );
  HDFReadVector( snaphdf5, "Data_Pos", ppos );
  std::cout << "done!" << std::endl;
  //for(unsigned i=0; i<nParticles; ++i)
  //	std::cout<<pmass.at(i)<<std::endl;

  float dx = boxsize / N;
  float Omegam0 = 0.25f;
  float a = 1.0f;
  float H0 = 100.0;
  float rho0 = 3.0f * H0 * H0 / 8.0 / M_PI / G_const * Omegam0;
  // what's the difference to dx?
  float r0 = boxsize / N;
  float t0 = 1.0f / H0;
  float v0 = r0 / t0;
  float phi0 = v0 * v0;


  // filter size is directly specified, Gaussian
  float sigma = Radius / r0;

  std::cout << " * * # particles     = " << nParticles << std::endl;
  std::cout << " * * boxsize         = " << boxsize << "kpc/h" << std::endl;
  std::cout << " * * smooth @ Radius = " << Radius << "kpc/h" << std::endl;
  std::cout << " * * sigma           = " << sigma << std::endl;
  std::cout << " * * gridlength N    = " << N << std::endl;
  std::cout << " * * r0              = " << r0 << std::endl;
  std::cout << " * * dx              = " << dx << std::endl;

  unsigned nx, ny, nz;
  nx = ny = nz = N;
  // will there be a special simulation where we do need different names for nx, ny, nz at all? no. so just use N instead of nx, ny, nz
  const int nstencil = 3;

  ScalarField rho( nx, ny, nz, dx, nstencil );

  for ( unsigned i = 0; i < ppos.size(); ppos[ i ] /= r0, ++i );

  std::cout << " * Putting Cloud in Cell..." << std::endl;
  rho.put_CIC<float>( nParticles, &ppos[ 0 ], &pmass[ 0 ] );
  std::cout << " * done!" << std::endl;

  PoissonSolver<nstencil> psolver( &rho );
  ScalarField phi( nx, ny, nz, dx, nstencil );
  std::cout << " * Invoking FFT Poisson solver..." << std::endl;
  psolver.solve( &phi, boxsize, sigma );
  std::cout << "done!" << std::endl;

  unsigned nhalos;
  double nhalos2;

  std::cout << " * Reading Number of Halos..." << std::flush;
  HDFReadGroupAttribute( extrahdf5, "Header", "NumHalos", nhalos2 );
  nhalos = int( nhalos2 );
  std::cout << "gives " << nhalos2 << "=?" << nhalos << ", done!"<<std::endl;
  std::cout << " * Reading positions of COM..." << std::flush;
  std::vector<float> xcm( 3 * nhalos );
  HDFReadVector( extrahdf5, "hp_PosCM", xcm );
  std::cout << "done!" << std::endl;

  std::cout << " * Converting coordinates to grid units...";
  for ( unsigned i = 0; i < 3*nhalos; ++i )
    xcm.at( i ) /= r0;
  std::cout << "done!" << std::endl;

  HDFCreateFile( tensorhdf5 );

  std::cout << " * Computing tensor components at given positions...";
  std::vector< Matrix33 > tij_cm;
  // dphi.diff_at( tij_cm, xcm, nhalos, boxsize );
  phi.diff2atCIC( &xcm[ 0 ], nhalos, tij_cm );
  std::cout << "done!" << std::endl;

  std::cout << " * Converting back to physical units...";
  float tnorm = 1.0 / ( 1.5 * Omegam0 / a );
  for ( unsigned i = 0; i < nhalos; ++i )
    for ( int j = 0; j < 3; ++j )
      for ( int k = 0; k < 3; ++k )
	( tij_cm[ i ] ) ( j, k ) *= tnorm;
  std::cout << "done!" << std::endl;

  StoreTensorField( tensorhdf5, nhalos, xcm, tij_cm, sigma );

  std::cout << " * Evaluating density field at given positions..." << std::endl;
  std::vector< float > datacm;

  for ( unsigned i = 0; i < nhalos; ++i )
    datacm.push_back( ( rho.get_CIC( xcm.at( 3 * i + 0 ), xcm.at( 3 * i + 1 ), xcm.at( 3 * i + 2 ) ) + 1.0 ) * rho0 / ( a * a * a ));

  HDFWriteDataset( tensorhdf5, "Density", datacm );
  datacm.clear();

  for ( unsigned i = 0; i < nhalos; ++i )
    datacm.push_back( rho.get_CIC( xcm.at( 3 * i + 0 ), xcm.at( 3 * i + 1 ), xcm.at( 3 * i + 2 ) ));

  HDFWriteDataset( tensorhdf5, "Overdensity", datacm );
  datacm.clear();

  for ( unsigned i = 0; i < nhalos; ++i )
    datacm.push_back( rho.get_CIC( xcm.at( 3 * i + 0 ), xcm.at( 3 * i + 1 ), xcm.at( 3 * i + 2 ) ) * phi0);

  HDFWriteDataset( tensorhdf5, "Potential", datacm );
  datacm.clear();
}

void TidalField( unsigned isnap, int N, double Radius ) {
  for(unsigned i=1; i<11; ++i){
    std::string snaphdf5 = Folder("output") + Snaps( isnap ) + "/snapshot.hdf5";
    std::string extrahdf5 = Folder("output") + Snaps( isnap ) +"/extra.hdf5";
    std::string tensorhdf5 = Folder("output") + Snaps( isnap ) +"/tensor_" + IntToString(i) + ".hdf5";
    std::cout << snaphdf5 << std::endl;
    std::cout << extrahdf5 << std::endl;
    std::cout << tensorhdf5 << std::endl;
    TidalField( snaphdf5, N, i*Radius, extrahdf5, tensorhdf5 );
  }
}
