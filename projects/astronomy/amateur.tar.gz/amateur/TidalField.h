/**************************************************************************
 *   Copyright (C) 2008 by Pascal Stephan Philipp Steger                   *
 *   psteger@phys.ethz.ch                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, ma  02111-1307, USA.             *
 ***************************************************************************/

/*!
 * \file TidalField.h
 * \brief Class declarations for invocation of -t
 */

#ifndef TIDALFIELD_H
#define TIDALFIELD_H

#include <math.h>
#include "DataStruct.h"

#define EPS_ACC 1.0e-6

template < int nOrder >
class GreensFunction {
  float m_dx;
 public:
  GreensFunction( float dx ) : m_dx( dx ) { }
  inline float apply( int k ) {
    std::cerr << " - Error: Calling non-specialized (i.e. non-implemented ) version of GreensFunction::apply!" << std::endl;
    return 1.0f;
  }
};

template <>
inline float GreensFunction<3>::apply( int k ) {
  float ss = sin( 0.5 * m_dx * ( float ) k );
  return 4.0*ss*ss;
}

template <>
inline float GreensFunction<5>::apply( int k ) {
  const static float a0 = 0.6666666666666666667;
  float ss = sin( 0.5 * m_dx * ( float ) k );
  return -a0*ss*ss*( cos( m_dx * ( float ) k ) - 7.0 );
}

template <>
inline float GreensFunction<7>::apply( int k ) {
  const static float a0 = -0.04444444444444444444;
  float ss = sin( 0.5 * m_dx * k );
  return a0*ss*ss*( 23.0 * cos( m_dx * ( float ) k ) - 2.0 * cos( 2.0 * m_dx * ( float ) k ) - 111.0 );
}

template <>
inline float GreensFunction<9>::apply( int k ) {
  const static float a0 = -1.58730159e-3;
  float ss = sin( 0.5 * m_dx * ( float ) k );
  return a0*ss*ss*( 779.0 * cos( m_dx * ( float ) k ) - 110.0 * cos( 2.0 * m_dx * ( float ) k )
		    + 9.0 * cos( 3.0 * m_dx * ( float ) k ) - 3198.0 );
}

template <>
inline float GreensFunction<11>::apply( int k ) {
  const static float a0 = -3.17460317e-4;
  float ss = sin( 0.5 * m_dx * ( float ) k );
  return a0*ss*ss*( 4343.0 * cos( m_dx * ( float ) k ) - 774.0 * cos( 2.0 * m_dx * ( float ) k )
		    + 109.0 * cos( 3.0 * m_dx * ( float ) k ) - 8.0 * cos( 4.0 * m_dx * ( float ) k )
		    - 16270.0 );
}

class array3 {
 protected:
  float *m_data;
  int m_nx, m_ny, m_nz;
  bool bRealContainer;
 public:

  array3( void )
    : m_data( NULL ), m_nx( 0 ), m_ny( 0 ), m_nz( 0 ), bRealContainer( false ) {}

  array3( float *dataptr, int nx, int ny, int nz )
    : m_data( dataptr ), m_nx( nx ), m_ny( ny ), m_nz( nz ), bRealContainer( false ) {}

  array3( int nx, int ny, int nz )
    : m_data( new float[ nx*ny*nz ] ), m_nx( nx ), m_ny( ny ), m_nz( nz ), bRealContainer( true ) {
    for ( long long i = 0; i < nx*ny*nz; ++i )
      m_data[ i ] = 0.0f;
  }

  ~array3() {
    if ( bRealContainer )
      delete[] m_data;
  }

  float& operator() ( int ix, int iy, int iz ) {
    return m_data[ ( ix * m_ny + iy ) * m_nz + iz ];
  }

  float operator() ( int ix, int iy, int iz ) const {
    return m_data[ ( ix * m_ny + iy ) * m_nz + iz ];
  }

  int get_size( void ) {
    return std::max( std::max( m_nx, m_ny ), m_nz );
  }

  void recreate( int nx, int ny, int nz ) {
    if ( bRealContainer )
      delete[] m_data;
    else
      bRealContainer = true;

    m_nx = nx;
    m_ny = ny;
    m_nz = nz;
    m_data = new float[ m_nx * m_ny * m_nz ];

    for ( long long i = 0; i < nx*ny*nz; ++i )
      m_data[ i ] = 0.0f;
  }
};

class ScalarField {

 protected:
  //  float *m_data;
  array3 m_data;
  //  std::vector<ScalarField> m_dy;

  float m_dx;
  unsigned m_nx, m_ny, m_nz;
  int m_nstencil, m_nsten2;

  float *m_pStencil1, *m_pStencil2;

  void diff_primitive( ScalarField*, bool bStagger = false );
 public:

  ScalarField( void )
    : m_dx( 0.0f ), m_nx( 0 ), m_ny( 0 ), m_nz( 0 ), m_nstencil( 0 ) { }

  ScalarField( unsigned nx, unsigned ny, unsigned nz, float dx, int nstencil )
    : m_data( nx, ny, nz ),   // m_dy( local_nx, ny, nz ),
    m_dx( dx ), m_nx( nx ), m_ny( ny ), m_nz( nz ), m_nstencil( nstencil ) {
    m_nsten2 = ( m_nstencil - 1 ) / 2;
  }

  void recreate( unsigned nx, unsigned ny, unsigned nz, float dx, int nstencil ) {
    m_nx = nx;
    m_ny = ny;
    m_nz = nz;
    m_nstencil = nstencil;
    m_dx = dx;
    m_nsten2 = ( nstencil - 1 ) / 2;
    m_data.recreate( m_nx, m_ny, m_nz );
  }

  template < typename T >
    inline float& operator() ( T ix, T iy, T iz ) {
    return m_data( ( int ) ix, ( int ) iy, ( int ) iz );
  }

  template < typename T >
    inline float operator() ( T ix, T iy, T iz ) const {
    return m_data( ( int ) ix, ( int ) iy, ( int ) iz );
  }

  inline int get_xsize( void ) {
    return m_nx;
  }
  inline int get_ysize( void ) {
    return m_ny;
  }
  inline int get_zsize( void ) {
    return m_nz;
  }
  inline float get_dx( void ) {
    return m_dx;
  }
  inline int get_stencil( void ) {
    return m_nstencil;
  }

  template < typename T >
    void put_CIC( unsigned npart, T *coord, float *wpar );

  //  void grad( ScalarField *dy );
  //  void diff( VectorField* dy );

  void lookup( float *Coord, unsigned nCoord, std::vector< float >& values ) {
    values.clear();
    for ( unsigned i = 0; i < nCoord; ++i ) {
      values.push_back( ( *this ) ( Coord[ 3 * i ], Coord[ 3 * i + 1 ], Coord[ 3 * i + 2 ] ) );
    }
  }

  void lookup( float *Coord, unsigned nCoord, float ll, unsigned N, std::vector< float >& values ) {
    values.clear();
    float factor = 1.0; //(float)N/ll;
    for ( unsigned i = 0; i < nCoord; ++i ) {
      values.push_back( ( *this ) ( Coord[ 3 * i ] * factor, Coord[ 3 * i + 1 ] * factor, Coord[ 3 * i + 2 ] * factor ) );
    }
  }

  template < typename T >
    T get_NGP( T *coord ) {
    int
      ix = ( int ) coord[ 0 ],
      iy = ( int ) coord[ 1 ],
      iz = ( int ) coord[ 2 ];

    return ( *this ) ( ix, iy, iz );
  }

  float get_CIC( float coordx, float coordy, float coordz ) {

    int
      ix = ( int ) coordx,
      iy = ( int ) coordy,
      iz = ( int ) coordz,
      ix1 = ( ix + 1 ) % m_nx,
      iy1 = ( iy + 1 ) % m_ny,
      iz1 = ( iz + 1 ) % m_nz;


    float
      dx = ( float ) ( coordx - ( float ) ix ),
      dy = ( float ) ( coordy - ( float ) iy ),
      dz = ( float ) ( coordz - ( float ) iz ),
      tx = 1.0 - dx,
      ty = 1.0 - dy,
      tz = 1.0 - dz;

    float
      f_xyz = ( *this ) ( ix, iy, iz ) * tx * ty * tz,
      f_Xyz = ( *this ) ( ix1, iy, iz ) * dx * ty * tz,
      f_xYz = ( *this ) ( ix, iy1, iz ) * tx * dy * tz,
      f_xyZ = ( *this ) ( ix, iy, iz1 ) * tx * ty * dz,
      f_XYz = ( *this ) ( ix1, iy1, iz ) * dx * dy * tz,
      f_XyZ = ( *this ) ( ix1, iy, iz1 ) * dx * ty * dz,
      f_xYZ = ( *this ) ( ix, iy1, iz1 ) * tx * dy * dz,
      f_XYZ = ( *this ) ( ix1, iy1, iz1 ) * dx * dy * dz;

    return f_xyz + f_Xyz + f_xYz + f_xyZ + f_XYz + f_XyZ + f_xYZ + f_XYZ;
  }

  void ChooseStencil( void );
  void diff2atCIC( float *Coord, unsigned nPoints, std::vector< Matrix33 > &t_ij );

  inline float diff1( int ix, int iy, int iz, int i ) {
    int iright[ 3 ];
    for ( int k = 0; k < 3; ++k )
      iright[ k ] = 0;
    iright[ i ] = + 1;

    float d1i = 0.0;

    for ( int ii = -m_nsten2; ii <= m_nsten2; ++ii ) {
      int iix = ( ix + ii * iright[ 0 ] + m_nx ) % m_nx;
      int iiy = ( iy + ii * iright[ 1 ] + m_ny ) % m_ny;
      int iiz = ( iz + ii * iright[ 2 ] + m_nz ) % m_nz;
      d1i += m_pStencil1[ ii + m_nsten2 ] * ( *this ) ( iix, iiy, iiz );
    }

    return d1i;
  }

  inline float diff2( int ix, int iy, int iz, int i, int j ) {
    // trace component of the Hessian?
    if ( i == j ) {

      int iright[ 3 ];

      for ( int k = 0; k < 3; ++k )
	iright[ k ] = 0;
      iright[ i ] = + 1;

      float d2ii = 0.0;

      for ( int ii = -m_nsten2; ii <= m_nsten2; ++ii ) {
	int iix = ( ix + ii * iright[ 0 ] + m_nx ) % m_nx;
	int iiy = ( iy + ii * iright[ 1 ] + m_ny ) % m_ny;
	int iiz = ( iz + ii * iright[ 2 ] + m_nz ) % m_nz;
	d2ii += m_pStencil2[ ii + m_nsten2 ] * ( *this ) ( iix, iiy, iiz );
      }
      return d2ii;
    }

    // off-trace component of the Hessian
    int jright[ 3 ];

    for ( int k = 0; k < 3; ++k )
      jright[ k ] = 0;
    jright[ j ] = + 1;

    float d1j = 0;

    for ( int ii = -m_nsten2; ii <= m_nsten2; ++ii ) {
      int iix = ( ix + ii * jright[ 0 ] + m_nx ) % m_nx;
      int iiy = ( iy + ii * jright[ 1 ] + m_ny ) % m_ny;
      int iiz = ( iz + ii * jright[ 2 ] + m_nz ) % m_nz;
      d1j += m_pStencil1[ ii + m_nsten2 ] * this->diff1( iix, iiy, iiz, i );
    }

    return d1j;
  }
};

void TidalField( unsigned isnap, int N, double Radius );

#endif
