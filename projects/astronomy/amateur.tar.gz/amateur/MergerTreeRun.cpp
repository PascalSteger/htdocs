/**************************************************************************
 *   Copyright (C) 2008 by Pascal Stephan Philipp Steger                   *
 *   psteger@phys.ethz.ch                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, ma  02111-1307, USA.             *
 ***************************************************************************/

/*!
 * \file MergerTreeRun.cpp
 * \brief Rewrite of MergerTree of AMIGA, implements -m
 */

#include <fstream>
#include <iostream>
#include <string>
#include "SystemCharacteristics.h"

void RewriteParticleNumbers(unsigned isnap)
{
  std::
    cout << " * Extracting particle numbers... for #(halos) = " <<
    std::flush;
  std::ifstream fin;
  std::ofstream fout;
  fin.open((Folder("output") + Snaps(isnap) + "/ahf_out_particles").
	   c_str(), std::ios_base::in);
  fout.open((Folder("output") + Snaps(isnap) + "/ahf_out_particles2").
	    c_str(), std::ios_base::out);
  int Idummy = 0;
  int Ihalos = 0;
  int Icounter = 0;
  float Fdummy = 0.0f;

  fin >> Ihalos;
  std::cout << Ihalos << std::flush;
  for (; Ihalos > 0; --Ihalos) {
    fin >> Idummy;
    fin >> Icounter;
    fout << Icounter << std::endl;
    fin >> Fdummy;
    for (int i = 0; i < Icounter; ++i) {
      fin >> Idummy;
      fout << Idummy << std::endl;
      fin >> Idummy;
      fin >> Fdummy;
    }
  }

  fin.close();
  fout.close();
  std::cout << "done!" << std::endl;
}

void CreateMergeParameterFile(unsigned isnap)
{
  std::
    cout << " * Creating MergerTree parameter file..." <<
    Folder("amigabin");
  std::ofstream fout;
  fout.open((Folder("amigabin") + "parameters_MergerTree.txt").c_str(),
	    std::ios_base::out);
  // taken out _particles'''2'''
  fout << "2" << std::
    endl << Folder("output") << Snaps(isnap) << "/ahf_out_particles2"
       << std::endl;
  fout << Folder("output") << Snaps(isnap) << "/ahf_out_particles2" <<
    std::endl;
  fout << Folder("output") << Snaps(isnap) << "/ahf_out_mtree" << std::
    endl << std::endl;
  fout.close();
  std::cout << "done!" << std::endl;
}

void RunMergerTree(void)
{
  std::cout << " * Running MergerTree..." << std::endl;
  std::string now = "";
  now =
    Folder("amigabin") + "./MergerTree < " + Folder("amigabin") +
    "parameters_MergerTree.txt";
  RunCommand(now);
  //std::cin.get(); //wait for input
}

#include <map>
void RunOwnMergerTree(int isnap)
{
  std::cout << " * Running own MergerTree..." << std::endl;
  std::
    cout << " * * Extracting particle numbers... for #(halos) = " <<
    std::flush;
  std::ifstream fin;
  std::ofstream fout;
  fin.open((Folder("output") + Snaps(isnap) + "/ahf_out_particles").
	   c_str(), std::ios_base::in);
  fout.open((Folder("output") + Snaps(isnap) + "/ahf_out_particles2").
	    c_str(), std::ios_base::out);
  std::multimap < int, int >Particle_n_Halo;
  int Idummy = 0;
  int Ihalos = 0;
  int Icounter = 0;
  float Fdummy = 0.0f;

  fin >> Ihalos;
  std::cout << Ihalos << std::endl << std::flush;
  int pop[Ihalos];
  for (int i = 0; i < Ihalos; ++i)
    pop[i] = 0;
  for (int i = 0; i < Ihalos; ++i) {
    fin >> Idummy;		// which halo number
    fin >> Icounter;	// how many particles are inside this halo?
    pop[Idummy] = Icounter;
    fout << Icounter << std::endl;
    std::cout << Icounter << " particles in halo " << Idummy << std::
      endl;
    fin >> Fdummy;
    for (int j = 0; j < Icounter; ++j) {
      fin >> Idummy;	// particle number
      fout << Idummy << std::endl;
      Particle_n_Halo.insert(std::make_pair(Idummy, i));
      fin >> Idummy;
      fin >> Fdummy;
    }
  }
  std::cout << "done!" << std::endl;

  std::cout << " * Searching for shared particles..." << std::endl;
  int *SH = new int[Ihalos * Ihalos];
  for (int m = 0; m < Ihalos; ++m)
    for (int n = 0; n < Ihalos; ++n)
      SH[m * Ihalos + n] = 0;
  std::cout << " * * Starting map iterating..." << std::endl;
  for (std::multimap < int, int >::iterator iter = Particle_n_Halo.begin();
       iter != Particle_n_Halo.end(); ++iter) {
    std::multimap < int, int >::iterator iter2 = iter, iter3;
    iter2 = Particle_n_Halo.find(iter->first);
    iter3 = Particle_n_Halo.upper_bound(iter->first);
    //std::
    //cout << " * * * Checking for all halos the particle " << iter->
    //first << " belong to...";
    while (iter2 != iter3 ){//Particle_n_Halo.end()) {
      int m = iter->second;
      int n = iter2->second;
      //std::cout << n << " ";
      SH[m * Ihalos + n]++;
      iter2++;
      //iter2 = Particle_n_Halo.find(iter->first);
    }
    //std::cout << std::endl;
  }
  std::cout << "done!" << std::endl;

  std::cout << " * Output..." << std::flush;
  std::string ff = Folder("output") + Snaps(isnap) + "/ahf_out_mtree";
  std::ofstream foutm(ff.c_str());
  for (int m = 0; m < Ihalos; ++m) {
    for (int n = 0; n < Ihalos; ++n) {
      if(SH[m * Ihalos + n] > 0)
	foutm << m << " " << pop[m] << " " << SH[m * Ihalos +
						 n] << " " << n << " " <<
	  pop[n] << std::endl;
    }
  }
  std::cout << "done!" << std::endl;

  std::cout << " * Closing files...";
  fin.close();
  fout.close();
  foutm.close();
  std::cout << "done!" << std::endl;

  delete[]SH;
  //std::cin.get(); //wait for input
}

void MoveMergeOut(unsigned isnap)
{
  std::cout << " * Moving ahf_out_ files...";
  std::string now = "mv ahf_out_* " + Folder("output") + Snaps(isnap);
  RunCommand(now);
  std::cout << "done!" << std::endl;
}

void MergerTreeRun(unsigned isnap)
{
  //RewriteParticleNumbers( isnap );
  //CreateMergeParameterFile( isnap ); //for AMIGA's MergerTree (buggy?)
  RunOwnMergerTree(isnap);
  //MoveMergeOut (isnap);
}
