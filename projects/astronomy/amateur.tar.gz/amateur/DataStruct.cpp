/**************************************************************************
 *   Copyright (C) 2008 by Pascal Stephan Philipp Steger                   *
 *   psteger@phys.ethz.ch                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, ma  02111-1307, USA.             *
 ***************************************************************************/

/*!
 * \file DataStruct.cpp
 * \brief Implementations of Vector3 and Matrix33
 */

#include <math.h>
#include <iterator>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <list>
#include <vector>
#include <iterator>
#include <cassert>

#include <gsl/gsl_math.h>
#include <gsl/gsl_eigen.h>
#include "DataStruct.h"


#ifdef LONGIDS
typedef unsigned long Identifier;
typedef unsigned long Size;
#define HDF_UINT H5T_NATIVE_UINT64
#define MPI_UINT MPI_UNSIGNED_LONG
#else

typedef unsigned Identifier;
typedef unsigned Size;
#define HDF_UINT H5T_NATIVE_UINT
#define MPI_UINT MPI_UNSIGNED
#endif
#define HDF_FLOAT H5T_NATIVE_FLOAT
typedef float Scalar;
typedef float Weight;

#define FIX(x) (Identifier)(x+0.5)

Vector3::Vector3( void ) {
  m_Data = new double[ 3 ];
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] = 0.0;
}

Vector3::Vector3( const Vector3& v ) {
  m_Data = new double[ 3 ];
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] = v.m_Data[ i ];
}

Vector3::Vector3( double x){
  m_Data = new double[ 3 ];
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] = x;
}

Vector3::Vector3( double x, double y, double z ) {
  m_Data = new double[ 3 ];
  m_Data[ 0 ] = x;
  m_Data[ 1 ] = y;
  m_Data[ 2 ] = z;
}

template < typename real_t > 
Vector3::Vector3( const real_t* x0 ) {
  m_Data = new double[ 3 ];
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] = x0[ i ];
}

Vector3::~Vector3() {
  delete[] m_Data;
}

//inline
Vector3& 
Vector3::operator=( const Vector3& b ) {
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] = b.m_Data[ i ];
  return *this;
}

//inline 
Vector3& 
Vector3::operator=( const double& x ) {
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] = x;
  return *this;
}

//inline 
Vector3& 
Vector3::operator-( void ) {
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] = -m_Data[ i ];
  return *this;
}

//inline
Vector3 
Vector3::operator+( const Vector3& x ) const {
  Vector3 temp;
  for ( unsigned i = 0; i < 3; i++ )
    temp.m_Data[ i ] = m_Data[ i ] + x.m_Data[ i ];
  return temp;
}

//inline 
Vector3 
Vector3::operator-( const Vector3& x ) const {
  Vector3 temp;
  for ( unsigned i = 0; i < 3; i++ )
    temp.m_Data[ i ] = m_Data[ i ] - x.m_Data[ i ];
  return temp;
}

//inline 
Vector3 
Vector3::operator*( const double& x ) {
  Vector3 temp;
  for ( unsigned i = 0; i < 3; i++ )
    temp.m_Data[ i ] = m_Data[ i ] * x;
  return temp;
}

//inline 
Vector3 
Vector3::operator/( const double& x ) {
  Vector3 temp;
  for ( unsigned i = 0; i < 3; i++ )
    temp.m_Data[ i ] = m_Data[ i ] / x;
  return temp;
}

//inline 
Vector3& 
Vector3::operator+=( const Vector3& x ) {
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] += x.m_Data[ i ];
  return *this;
}

//inline 
Vector3& 
Vector3::operator-=( const Vector3& x ) {
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] -= x.m_Data[ i ];
  return *this;
}

//inline 
Vector3& 
Vector3::operator*=( const double& x ) {
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] *= x;
  return *this;
}

//inline 
Vector3& 
Vector3::operator/=( const double& x ) {
  for ( unsigned i = 0; i < 3; i++ )
    m_Data[ i ] /= x;
  return *this;
}

//inline 
double& 
Vector3::operator() ( const unsigned i ) {
  return m_Data[ i ];
}

// dot product
//inline 
double 
Vector3::operator*( const Vector3& vb ) const {
  double res = 0.0;
  for ( unsigned i = 0; i < 3; i++ )
    res += m_Data[ i ] * vb.m_Data[ i ];
  return res;
}

// cross product
//inline 
Vector3 
Vector3::operator^( const Vector3& vb ) const {
  Vector3 temp;

  temp.m_Data[ 0 ] = m_Data[ 1 ] * vb.m_Data[ 2 ] - m_Data[ 2 ] * vb.m_Data[ 1 ];
  temp.m_Data[ 1 ] = m_Data[ 2 ] * vb.m_Data[ 0 ] - m_Data[ 0 ] * vb.m_Data[ 2 ];
  temp.m_Data[ 2 ] = m_Data[ 0 ] * vb.m_Data[ 1 ] - m_Data[ 1 ] * vb.m_Data[ 0 ];

  return temp;
}

//inline 
double 
Vector3::norm( void ) const {
  return sqrt( ( *this ) * ( *this ) );
}

//inline
double 
Vector3::norm2( void ) const {
  return ( *this ) * ( *this );
}

//inline 
Vector3& 
Vector3::normalize( void ) {
  if ( norm2() < 1e-10 )
    return *this;
  *this /= norm();
  return *this;
}

// 	inline Vector& moduloBox( const Vector& vm ) {
// 		for( Identifier i=0; i<N; ++i ) {
// 			if(m_Data[i] < -vm[i]/2) m_Data[i] += vm[i];
// 			if(m_Data[i] > vm[i]/2) m_Data[i] -= vm[i];
// 		}
// 	}

// output
std::ostream& 
operator<<( std::ostream& s, Vector3 v ) {
  s << v( 0 );
  for ( unsigned i = 1; i < 3 && s << " "; ++i )
    s << v( i );
  return s;
}


Matrix33::Matrix33() {
  m_Data = new double[ 3 * 3 ];
}

Matrix33::Matrix33( const Matrix33& m ) {
  m_Data = new double[ 3 * 3 ];
  for ( Identifier i = 0; i < 3*3; i++ )
    m_Data[ i ] = m.m_Data[ i ];
}

Matrix33::~Matrix33() {
  delete[] m_Data;
};

//inline 
double& 
Matrix33::operator() ( Identifier row, Identifier col ) {
  return m_Data[ col + row * 3 ];
}

//inline 
double 
Matrix33::operator() ( Identifier row, Identifier col ) const {
  return m_Data[ col + row * 3 ];
}

//inline 
Vector3 
Matrix33::operator() ( Identifier col ) {
  Vector3 v;
  for ( unsigned i = 0; i < 3; ++i )
    v( i ) = ( *this ) ( i, col );
  return v;
}

//inline 
Matrix33& 
Matrix33::operator= ( Matrix33 const &M ) {
  Identifier i;
  for ( i = 0;i < 3*3;i++ )
    m_Data[ i ] = M.m_Data[ i ];
  return *this;
}

//inline 
Matrix33& 
Matrix33::operator= ( const double& x ) {
  Identifier i;
  for ( i = 0;i < 3*3;i++ )
    m_Data[ i ] = x;
  return *this;
}

//inline 
Vector3 
Matrix33::operator[] ( Identifier col ) const {
  Vector3 v;
  for ( Identifier i = 0;i < 3;++i )
    v( i ) = m_Data[ col + i * 3 ];
  return v;
}

//inline 
Matrix33& 
Matrix33::operator+=( const Matrix33& m ) {
  for ( Identifier i = 0; i < 3*3; i++ )
    m_Data[ i ] += m.m_Data[ i ];
  return *this;
}

//inline 
Matrix33& 
Matrix33::operator-=( const Matrix33& m ) {
  for ( Identifier i = 0; i < 3*3; i++ )
    m_Data[ i ] -= m.m_Data[ i ];
  return *this;
}

//inline 
Matrix33 
Matrix33::operator*( const double& x ) {
  Matrix33 temp;
  for ( Identifier i = 0; i < 3*3; i++ )
    temp.m_Data[ i ] = m_Data[ i ] * x;
  return temp;
}

//inline 
Matrix33 
Matrix33::operator/( const double& x ) {
  Matrix33 temp;
  double ix = 1.0 / x;
  for ( Identifier i = 0; i < 3*3; i++ )
    temp.m_Data[ i ] = m_Data[ i ] * ix;
  return temp;
}

//inline 
void 
Matrix33::set_diag( Vector3 diag ) {
  *this = 0.0;
  for ( unsigned i = 0; i < 3; ++i ) {
    ( *this ) ( i, i ) = diag( i );
  }
}

void 
Matrix33::Eigen( Vector3& lambda, std::vector<Vector3>& V ) const {
  gsl_matrix_view m = gsl_matrix_view_array( m_Data, 3, 3 );
  gsl_vector *eval = gsl_vector_alloc ( 3 );
  gsl_matrix *evec = gsl_matrix_alloc ( 3, 3 );
  gsl_eigen_symmv_workspace * w = gsl_eigen_symmv_alloc ( 3 );

  gsl_eigen_symmv ( &m.matrix, eval, evec, w );
  gsl_eigen_symmv_free ( w );
  //gsl_eigen_symmv_sort ( eval, evec, GSL_EIGEN_SORT_ABS_ASC );
  gsl_eigen_symmv_sort ( eval, evec, GSL_EIGEN_SORT_VAL_ASC );

  for ( unsigned i = 0; i < 3; ++i ) {
    //double eval_i = gsl_vector_get (eval, i);
    gsl_vector_view evec_i = gsl_matrix_column (evec, i);
    lambda( i ) = gsl_vector_get ( eval, i );
    V.push_back( Vector3() );
		
    for ( unsigned j = 0; j < 3; ++j )
      (V.at(i))(j) = gsl_vector_get( &evec_i.vector, j );
    //V( i, j ) = gsl_matrix_get( evec, i, j );
  }
}

double 
Matrix33::det( void ) const {
  Vector3 l;
  std::vector<Vector3> V;
  this->Eigen( l, V );
  double d = 1.0;
  for ( unsigned i = 0; i < 3; ++i )
    d *= l( i );
  return d;
}

Vector3 
Matrix33::get_invariants(std::vector<Vector3>& V) const {
  Vector3 EV,inv;
  Eigen(EV,V);
  inv(0)=EV(0)+EV(1)+EV(2);
  inv(1)=EV(0)*EV(1)+EV(1)*EV(2)+EV(0)*EV(2);
  inv(2)=EV(0)*EV(1)*EV(2);
  return inv;
}

#define ROTATE(a,i,j,k,l) g=(a)(i,j);h=(a)(k,l);(a)(i,j)=g-s*(h+g*tau);\
	(a)(k,l)=h+s*(g-h*tau);

void 
Matrix33::Jacobi( Vector3& lambda, Matrix33& V, int &nrot ) {
  int j, iq, ip, i;
  double tresh, theta, tau, t, sm, s, h, g, c;
  double *b = new double[ 3 ],
    *z = new double[ 3 ];

  //... set output matrix to identity matrix ...
  for ( ip = 0; ip < 3; ip++ ) {
    for ( iq = 0; iq < 3; iq++ )
      V( ip, iq ) = 0.0;
    V( ip, ip ) = 1.0;
  }

  for ( ip = 0; ip < 3; ip++ ) {
    b[ ip ] = lambda( ip ) = ( *this ) ( ip, ip );
    z[ ip ] = 0.0;
  }
  nrot = 0;
  for ( i = 0; i < 50;i++ ) {
    sm = 0.0;
    for ( ip = 0; ip < 2;ip++ ) {
      for ( iq = ip + 1;iq < 3; ++iq )
	sm += fabs( ( *this ) ( ip, iq ) );
    }
    if ( sm == 0.0 ) {
      delete[] b;
      delete[] z;
      return ;
    }
    if ( i < 4 )
      tresh = 0.2 * sm / ( 3 * 3 );
    else
      tresh = 0.0;
    for ( ip = 0; ip < 2; ip++ ) {
      for ( iq = ip + 1; iq < 3; iq++ ) {
	g = 100.0 * fabs( ( *this ) ( ip, iq ) );
	if ( i > 4 && ( double ) ( fabs( lambda( ip ) ) + g ) == ( double ) fabs( lambda( ip ) )
	     && ( double ) ( fabs( lambda( iq ) ) + g ) == ( double ) fabs( lambda( iq ) ) )
	  ( *this ) ( ip, iq ) = 0.0;
	else if ( fabs( ( *this ) ( ip, iq ) ) > tresh ) {
	  h = lambda( iq ) - lambda( ip );
	  if ( ( double ) ( fabs( h ) + g ) == ( double ) fabs( h ) )
	    t = ( ( *this ) ( ip, iq ) ) / h;
	  else {
	    theta = 0.5 * h / ( ( *this ) ( ip, iq ) );
	    t = 1.0 / ( fabs( theta ) + sqrt( 1.0 + theta * theta ) );
	    if ( theta < 0.0 )
	      t = -t;
	  }
	  c = 1.0 / sqrt( 1 + t * t );
	  s = t * c;
	  tau = s / ( 1.0 + c );
	  h = t * ( ( *this ) ( ip, iq ) );
	  z[ ip ] -= h;
	  z[ iq ] += h;
	  lambda( ip ) -= h;
	  lambda( iq ) += h;
	  ( *this ) ( ip, iq ) = 0.0;
	  for ( j = 0; j < ip - 1;j++ ) {
	    ROTATE( *this, j, ip, j, iq );
	  }
	  for ( j = ip + 1;j <= iq - 1;j++ ) {
	    ROTATE( *this, ip, j, j, iq );
	  }
	  for ( j = iq + 1;j < 3;j++ ) {
	    ROTATE( *this, ip, j, iq, j );
	  }
	  for ( j = 0;j < 3;j++ ) {
	    ROTATE( V, j, ip, j, iq );
	  }
	  ++nrot;
	}
      }
    }
    for ( ip = 0; ip < 3; ++ip ) {
      b[ ip ] += z[ ip ];
      lambda( ip ) = b[ ip ];
      z[ ip ] = 0.0;
    }
  }
  std::cerr << "Error : Too many iterations in routine Jacobi";
  delete[] b;
  delete[] z;
}
