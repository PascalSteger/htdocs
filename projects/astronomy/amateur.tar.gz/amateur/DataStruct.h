/**************************************************************************
 *   Copyright (C) 2008 by Pascal Stephan Philipp Steger                   *
 *   psteger@phys.ethz.ch                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, ma  02111-1307, USA.             *
 ***************************************************************************/

/*!
 * \file DataStruct.h
 * \brief Contains class headers for Vector3 and Matrix33
 */

#ifndef DATASTRUCT_H
#define DATASTRUCT_H

#include <math.h>
#include <iterator>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <list>
#include <vector>
#include <iterator>
#include <cassert>

#include <gsl/gsl_math.h>
#include <gsl/gsl_eigen.h>

#ifdef LONGIDS
typedef unsigned long Identifier;
typedef unsigned long Size;
#define HDF_UINT H5T_NATIVE_UINT64
#define MPI_UINT MPI_UNSIGNED_LONG
#else

typedef unsigned Identifier;
typedef unsigned Size;
#define HDF_UINT H5T_NATIVE_UINT
#define MPI_UINT MPI_UNSIGNED
#endif
#define HDF_FLOAT H5T_NATIVE_FLOAT
typedef float Scalar;
typedef float Weight;

#define FIX(x) (Identifier)(x+0.5)

class Vector3 {
 protected:
  double *m_Data;
 public:
  Vector3( void );
  Vector3( const Vector3& v );
  Vector3( double x);
  Vector3( double x, double y, double z );

  template < typename real_t > Vector3( const real_t* x0 );

  ~Vector3();

  Vector3& operator=( const Vector3& b );
  Vector3& operator=( const double& x );
  Vector3& operator-( void );
  Vector3 operator+( const Vector3& x ) const;
  Vector3 operator-( const Vector3& x ) const;
  Vector3 operator*( const double& x );
  Vector3 operator/( const double& x );
  Vector3& operator+=( const Vector3& x );
  Vector3& operator-=( const Vector3& x );
  Vector3& operator*=( const double& x );
  Vector3& operator/=( const double& x );
  double& operator() ( const unsigned i );
  //dot product
  double operator*( const Vector3& vb ) const;
  // cross product
  Vector3 operator^( const Vector3& vb ) const;
  double norm( void ) const;
  double norm2( void ) const;
  Vector3& normalize( void );
};

std::ostream& 
operator<<( std::ostream& s, Vector3 v );

class Matrix33 {
 protected:
  double *m_Data;
 public:
  Matrix33();
  Matrix33( const Matrix33& m );
  ~Matrix33();

  double& operator() ( Identifier row, Identifier col );
  double operator() ( Identifier row, Identifier col ) const;
  Vector3 operator() ( Identifier col );
  Matrix33& operator= ( Matrix33 const &M );
  Matrix33& operator= ( const double& x );
  Vector3 operator[] ( Identifier col ) const;
  Matrix33& operator+=( const Matrix33& m );
  Matrix33& operator-=( const Matrix33& m );
  Matrix33 operator*( const double& x );
  Matrix33 operator/( const double& x );
  void set_diag( Vector3 diag );
  void Jacobi( Vector3& lambda, Matrix33& V, int& nrot );
  void Eigen( Vector3& lambda, std::vector<Vector3>& V ) const;
  double det( void ) const;
  Vector3 get_invariants( std::vector<Vector3>& V ) const;
};

#endif
