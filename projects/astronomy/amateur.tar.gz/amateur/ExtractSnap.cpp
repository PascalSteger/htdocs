/***************************************************************************
 *   Copyright (C) 2008 by Pascal Stephan Philipp Steger                   *
 *   psteger@phys.ethz.ch                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, ma  02111-1307, USA.             *
 ***************************************************************************/

/*!
 * \file ExtractSnap.cpp
 * \brief Write binary Gadget2 snapshot into HDF5
 */

#include <fstream>
#include <iostream>
#include <numeric>
#include <string>
#include <string.h>
#include <vector>
#include <cstdlib>
#include "HDFIO.h"
#include "ReadGadget.h"
#include "SystemCharacteristics.h"

/* \brief Write binary snapshot file to HDF5 */
/**
 * Takes a binary Fortran-formatted snapshot file and writes the contents into HDF5
 * \param isnap: ID of snapshot file
 * \return void
 */
void 
ExtractSnap( unsigned isnap ) {
  std::string SnapshotString = Snaps( isnap );

  std::cout << " * Getting particle numbers..." << std::endl;
  unsigned npart[ 6 ], ntot;
  unsigned id_min[ 6 ], id_max[ 6 ];
  double Redshift, Boxsize;
  double masses[ 6 ];

  std::string fn_snap = Folder("snaps") + SnapshotString;
  get_particle_number ( fn_snap.c_str(), id_min, id_max, masses, npart, ntot, Redshift, Boxsize );
  std::cout << "done!" << std::endl;

  std::cout << " * offsets: ";
  unsigned offs[ 6 ];
  for ( int x = 0; x < 6; ++x ) {
    offs[ x ] = std::accumulate( &npart[ 0 ], &npart[ x ], 0 );
    std::cout << offs[ x ] << " ";
  }
  std::cout << std::endl;

  int n;
  unsigned * id;
  float * pos, * vel, * mass, * temp, * u, * rho;

  std::cout << "Allocating memory...";
  id   = ( unsigned * ) malloc( ntot * sizeof( unsigned ) );
  pos  = ( float * )    malloc( 3 * ntot * sizeof ( float ) );
  vel  = ( float * )    malloc( 3 * ntot * sizeof ( float ) );
  mass = ( float * )    malloc( ntot * sizeof( float ) );
  unsigned ngas = npart[0];
  temp = ( float * )    malloc( ngas * sizeof( float ) );
  u    = ( float * )    malloc( ngas * sizeof( float ) );
  rho  = ( float * )    malloc( ngas * sizeof( float ) );
  std::cout << "done!" << std::endl;

  std::cout << "Reading data blocks..." << std::endl;
  FILE *SnapshotFile = 0;

  SnapshotFile = fopen ( fn_snap.c_str(), "r" );
  n = read_gadget_1( ( unsigned * ) id,   "ID  ", SnapshotFile );
  n = read_gadget_3( ( float * )    pos,  "POS ", SnapshotFile );
  n = read_gadget_3( ( float * )    vel,  "VEL ", SnapshotFile );
  n = read_gadget_1( ( float * )    mass, "MASS", SnapshotFile );
  n = read_gadget_1( ( float * )    temp, "TEMP", SnapshotFile );
  n = read_gadget_1( ( float * )    u,    "U   ", SnapshotFile );
  n = read_gadget_1( ( float * )    rho,  "RHO ", SnapshotFile );
  std::cout << "done!" << std::endl << std::endl;

  fclose ( SnapshotFile );

  std::cout << "Writing raw snapshot data into HDF5...";
  std::cout.flush();
  std::string now = "mkdir -p " + Folder("output") + SnapshotString;
  RunCommand( now );
  std::string fn_out = Folder("output") + SnapshotString + "/snapshot.hdf5";
  HDFCreateFile( fn_out );
  HDFCreateGroup( fn_out, "Header" );
  HDFWriteGroupAttribute( fn_out, "Header", "Boxsize", Boxsize );
  HDFWriteGroupAttribute( fn_out, "Header", "NumParticles", ntot );
  HDFWriteGroupAttribute( fn_out, "Header", "Redshift", Redshift );
  std::vector<float> rtype(ntot), rpos( 3 * ntot ), rvel( 3 * ntot ), rmass( ntot ), rid( ntot ), ru(ngas), rtemp(ngas), rrho(ngas);

  for ( unsigned i = 0, i3 = 0; i < ntot; ++i, i3 = 3 * i ) {
    for ( unsigned j = 0; j < 3; ++j ) {
      rpos.at( i3 + j ) = pos[ i3 + j ];
      rvel.at( i3 + j ) = vel[ i3 + j ];
    }
    rmass.at( i ) = mass[ i ];
    rid.at( i ) = id[ i ];
  }
  for(unsigned i=0; i<ngas; ++i){
    ru.at(i)=u[i];
    rtemp.at(i)=temp[i];
    rrho.at(i)=rho[i];
  }

  HDFWriteDatasetVector( fn_out, "Data_Pos",  rpos );
  HDFWriteDatasetVector( fn_out, "Data_Vel",  rvel );
  HDFWriteDataset( fn_out,       "Data_ID",   rid );
  HDFWriteDataset( fn_out,       "Data_Mass", rmass );
  HDFWriteDataset( fn_out,       "Data_U",    ru );
  HDFWriteDataset( fn_out,       "Data_Rho",  rrho );
  HDFWriteDataset( fn_out,       "Data_Temp", rtemp );

  std::cout << "done!" << std::endl;
}
